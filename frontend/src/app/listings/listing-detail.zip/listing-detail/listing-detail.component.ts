import { Component, OnInit, HostListener } from '@angular/core';
import { CommonModule, DatePipe, DecimalPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { ListingService } from '../../services/listing.service';
import { AuthService }    from '../../services/auth.service';
import { ChatService }    from '../../modules/chat/chat.service';
import { BookingService } from '../../modules/bookings/booking.service';
import { Listing, ListingOwner, PRICE_UNIT_LABELS } from '../../models/listing.model';
import { AvailabilityCalendarComponent } from '../availability-calendar/availability-calendar.component';
import { ListingReviewsComponent } from '../../modules/reviews/listing-reviews.component';
import { WishlistService } from '../../modules/wishlist/wishlist.service';

@Component({
  selector: 'app-listing-detail',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, DatePipe, DecimalPipe, AvailabilityCalendarComponent, ListingReviewsComponent],
  templateUrl: './listing-detail.component.html',
  styleUrls: ['./listing-detail.component.css'],
})
export class ListingDetailComponent implements OnInit {
  listing:     Listing | null = null;
  activeImage  = '';
  loading      = true;
  error        = '';

  showDeleteModal = false;
  deleting        = false;
  deleteError     = '';

  isLoggedIn       = false;
  isOwnerOfListing = false;

  constructor(
    private route:          ActivatedRoute,
    private router:         Router,
    private listingService: ListingService,
    private authService:    AuthService,
    private chatSvc:        ChatService,
    private bookingSvc:     BookingService,
    private wishlistSvc:    WishlistService,
  ) {}

  ngOnInit(): void {
    this.isLoggedIn = this.authService.isLoggedIn;
    const id = this.route.snapshot.paramMap.get('id');
    if (!id) { this.error = 'Invalid listing ID.'; this.loading = false; return; }
    this.loadListing(id);
    if (this.isLoggedIn) this.wishlistSvc.getWishlist().subscribe();
  }

  loadListing(id: string): void {
    this.listingService.getListingById(id).subscribe({
      next: (res) => {
        this.listing     = res.data.listing;
        this.activeImage = this.listing.images?.[0]?.url || '';
        this.loading     = false;
        this.checkOwnership();
      },
      error: (err) => {
        this.error   = err.error?.message || 'Listing not found.';
        this.loading = false;
      },
    });
  }

  // Check if the currently logged-in user is the listing owner
  checkOwnership(): void {
    const currentUser = this.authService.currentUser;
    if (!currentUser || !this.listing) return;
    const ownerId = this.isOwnerObject(this.listing.createdBy)
      ? (this.listing.createdBy as any)._id || (this.listing.createdBy as any).id
      : this.listing.createdBy;
    this.isOwnerOfListing = currentUser.id === ownerId || (currentUser as any)._id === ownerId;
  }

  // Resolve the owner's user ID (createdBy may be an object or a raw ID)
  getOwnerId(): string | null {
    if (!this.listing) return null;
    const o: any = this.listing.createdBy;
    return this.isOwnerObject(o) ? (o._id || o.id) : o;
  }

  // 💬 Message Owner — start/get conversation, then go to /messages
  messageOwner(): void {
    const ownerId   = this.getOwnerId();
    const listingId = this.listing?._id || this.listing?.id;
    if (!ownerId) return;
    this.router.navigate(['/messages'], { queryParams: { userId: ownerId, listingId } });
  }

  // ── Availability calendar selection ──────────────────────────────────────────
  selectedRange: { start: Date; end: Date } | null = null;
  submitting = false;
  deliveryMethod: 'pickup' | 'delivery' = 'pickup';   // renter chooses how to receive the item

  onRangeSelected(range: { start: Date; end: Date }): void {
    this.selectedRange = range;
  }

  requestBooking(): void {
    if (!this.selectedRange || !this.listing) return;
    if (this.submitting) return;   // prevent double-submit
    this.submitting = true;
    const id = this.listing._id || this.listing.id;
    this.bookingSvc.create({
      listingId: id,
      startDate: this.toUtcDateString(this.selectedRange.start),
      endDate:   this.toUtcDateString(this.selectedRange.end),
      deliveryMethod: this.deliveryMethod,
    } as any).subscribe({
      next: (res: any) => {
        const bookingId = res?.data?.booking?.id || res?.data?.booking?._id;
        if (bookingId) this.router.navigate(['/bookings', bookingId]);
        else this.router.navigate(['/bookings']);
      },
      error: (err: any) => {
        this.submitting = false;
        alert(err?.error?.message || 'Could not create booking. Please try again.');
      },
    });
  }

  /** Convert a locally-picked date to a UTC-midnight ISO string (no day shift). */
  private toUtcDateString(d: Date): string {
    return new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate(), 0, 0, 0)).toISOString();
  }

  // ── Wishlist heart ───────────────────────────────────────────────────────────
  get isSaved(): boolean {
    const id = this.listing?._id || this.listing?.id;
    return id ? this.wishlistSvc.isSaved(id) : false;
  }

  toggleWishlist(): void {
    const id = this.listing?._id || this.listing?.id;
    if (!id) { alert('Listing ID missing'); return; }
    const wasSaved = this.wishlistSvc.isSaved(id);
    this.wishlistSvc.toggle(id).subscribe({
      next: () => {
        // success — signal already updated; optional toast
      },
      error: (err: any) => {
        const msg = err?.error?.message || err?.message || 'Could not update wishlist';
        alert('Wishlist error: ' + msg);
      },
    });
  }

  editListing(): void {
    const id = this.listing?.id || this.listing?._id;
    this.router.navigate(['/listings/edit', id]);
  }

  confirmDelete(): void {
    const id = this.listing?.id || this.listing?._id;
    if (!id) return;
    this.deleting     = true;
    this.deleteError  = '';
    this.listingService.deleteListing(id).subscribe({
      next: () => {
        this.deleting         = false;
        this.showDeleteModal  = false;
        this.router.navigate(['/listings']);
      },
      error: (err) => {
        this.deleting    = false;
        this.deleteError = err.error?.message || 'Failed to delete listing.';
      },
    });
  }

  // ── Display Helpers ────────────────────────────────────────────────────────
  getPriceLabel(unit: string): string {
    return PRICE_UNIT_LABELS[unit as keyof typeof PRICE_UNIT_LABELS] || '';
  }

  isOwnerObject(owner: any): owner is ListingOwner {
    return owner && typeof owner === 'object';
  }

  getOwnerInitial(owner: any): string {
    return typeof owner === 'object' && owner?.name ? owner.name.charAt(0).toUpperCase() : '?';
  }

  getOwnerName(owner: any): string {
    return typeof owner === 'object' ? owner?.name || 'Unknown' : 'Unknown';
  }

  getOwnerSince(owner: any): string {
    if (typeof owner === 'object' && owner?.createdAt) {
      return new Date(owner.createdAt).getFullYear().toString();
    }
    return '';
  }

  getOwnerCnic(owner: any): boolean {
    return typeof owner === 'object' && !!owner?.cnicVerified;
  }

  // ── Image gallery ────────────────────────────────────────────────────────────
  setActiveImage(url: string): void { this.activeImage = url; }

  lightboxOpen = false;
  lightboxIndex = 0;
  lightboxZoom = 1;
  get galleryImages(): string[] {
    return (this.listing?.images || []).map((im: any) => im?.url || im).filter((u: any) => !!u);
  }
  openLightbox(startIndex = 0): void {
    if (!this.galleryImages.length) return;
    this.lightboxIndex = startIndex; this.lightboxZoom = 1; this.lightboxOpen = true;
    document.body.style.overflow = 'hidden';
  }
  closeLightbox(): void { this.lightboxOpen = false; this.lightboxZoom = 1; document.body.style.overflow = ''; }
  lbNext(e?: Event): void { if (e) e.stopPropagation(); this.lightboxIndex = (this.lightboxIndex + 1) % this.galleryImages.length; this.lightboxZoom = 1; }
  lbPrev(e?: Event): void { if (e) e.stopPropagation(); this.lightboxIndex = (this.lightboxIndex - 1 + this.galleryImages.length) % this.galleryImages.length; this.lightboxZoom = 1; }
  lbZoomIn(e?: Event):  void { if (e) e.stopPropagation(); this.lightboxZoom = Math.min(this.lightboxZoom + 0.4, 3); }
  lbZoomOut(e?: Event): void { if (e) e.stopPropagation(); this.lightboxZoom = Math.max(this.lightboxZoom - 0.4, 1); }

  get relatedListings(): any[] { return (this.listing as any)?.related || []; }

  goToListing(l: any): void {
    const id = l._id || l.id;
    this.router.navigate(['/listings', id]).then(() => {
      window.scrollTo({ top: 0 });
      this.loading = true;
      this.loadListing(id);
    });
  }

  onImgError(event: Event): void {
    const img = event.target as HTMLImageElement;
    img.style.display = 'none';
    const ph = img.nextElementSibling as HTMLElement | null;
    if (ph) ph.style.display = 'flex';
  }

  @HostListener('document:keydown', ['$event'])
  onKey(e: KeyboardEvent): void {
    if (!this.lightboxOpen) return;
    if (e.key === 'Escape')          this.closeLightbox();
    else if (e.key === 'ArrowRight') this.lbNext();
    else if (e.key === 'ArrowLeft')  this.lbPrev();
    else if (e.key === '+' || e.key === '=') this.lbZoomIn();
    else if (e.key === '-')          this.lbZoomOut();
  }

  // ── Inline chat with owner ───────────────────────────────────────────────────
  chatOpen = false;
  chatLoading = false;
  chatSending = false;
  chatConversationId = '';
  chatMessages: any[] = [];
  chatDraft = '';

  openChat(): void {
    if (!this.isLoggedIn) { this.router.navigate(['/auth/login']); return; }
    const ownerId   = this.getOwnerId();
    const listingId = this.listing?._id || this.listing?.id;
    if (!ownerId) return;
    this.chatOpen = true;
    this.chatLoading = true;
    this.chatSvc.startConversation(ownerId, listingId as string).subscribe({
      next: (res: any) => {
        const conv = res?.data?.conversation || res?.data;
        this.chatConversationId = conv?._id || conv?.id || '';
        if (this.chatConversationId) this.loadChatMessages();
        else this.chatLoading = false;
      },
      error: () => { this.chatLoading = false; },
    });
  }

  loadChatMessages(): void {
    if (!this.chatConversationId) return;
    this.chatSvc.getMessages(this.chatConversationId, 1, 50).subscribe({
      next: (res: any) => {
        this.chatMessages = res?.data?.messages || res?.data || [];
        this.chatLoading = false;
        setTimeout(() => this.scrollChatBottom(), 50);
      },
      error: () => { this.chatLoading = false; },
    });
  }

  sendChat(): void {
    const text = this.chatDraft.trim();
    if (!text || this.chatSending || !this.chatConversationId) return;
    this.chatSending = true;
    const ownerId = this.getOwnerId();
    this.chatSvc.send({
      conversationId: this.chatConversationId,
      recipientId: ownerId,
      content: text,
      listingId: (this.listing?._id || this.listing?.id) as string,
    } as any).subscribe({
      next: (res: any) => {
        const msg = res?.data?.message || res?.data;
        if (msg) this.chatMessages.push(msg);
        this.chatDraft = '';
        this.chatSending = false;
        setTimeout(() => this.scrollChatBottom(), 50);
      },
      error: () => { this.chatSending = false; },
    });
  }

  closeChat(): void { this.chatOpen = false; }

  isMyMessage(m: any): boolean {
    const me: any = this.authService.currentUser;
    const myId = me?.id || me?._id;
    const sender = m?.sender?._id || m?.sender?.id || m?.sender || m?.senderId;
    return String(sender) === String(myId);
  }

  openFullChat(): void {
    this.router.navigate(['/messages', this.chatConversationId]);
  }

  private scrollChatBottom(): void {
    const el = document.querySelector('.lc-chat-body');
    if (el) el.scrollTop = el.scrollHeight;
  }
}
