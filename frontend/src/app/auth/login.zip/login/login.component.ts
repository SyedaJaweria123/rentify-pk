/**
 * LoginComponent — Rentify PK
 * ─────────────────────────────────────────────────────────────────────────────
 * Design: Split-screen — left green brand panel, right login form
 *
 * Features (all preserved from original):
 *   • Email + password login via AuthService.login()
 *   • Show/hide password toggle
 *   • Field-level validation errors
 *   • EMAIL_NOT_VERIFIED handling → shows resend link
 *   • Social login (Google / Facebook)
 *   • Social-error query param handling
 *   • returnUrl support → redirect back after login
 *   • Already-logged-in guard → redirect to dashboard
 * ─────────────────────────────────────────────────────────────────────────────
 */
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule, ActivatedRoute } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector:    'app-login',
  standalone:  true,
  imports:     [CommonModule, FormsModule, RouterModule],
  templateUrl: './login.component.html',
  styleUrls:   ['./login.component.css'],
})
export class LoginComponent implements OnInit {

  // ── Form fields ─────────────────────────────────────────────────────────
  email    = '';
  password = '';
  showPass = false;

  // ── UI state ────────────────────────────────────────────────────────────
  loading = false;
  error   = '';
  /** Per-field validation errors keyed by field name */
  fieldErrors: Record<string, string> = {};
  /** Set when login fails with EMAIL_NOT_VERIFIED — enables resend link */
  unverifiedEmail = '';

  /** URL to return to after successful login (e.g. from booking flow) */
  private returnUrl = '/dashboard';

  constructor(
    private auth:   AuthService,
    private router: Router,
    private route:  ActivatedRoute,
  ) {}

  ngOnInit(): void {
    // Already logged in? Skip the login page.
    if (this.auth.isLoggedIn) {
      this.router.navigate(['/dashboard']);
      return;
    }

    // Capture returnUrl so we can redirect back after login
    const ret = this.route.snapshot.queryParamMap.get('returnUrl');
    if (ret) this.returnUrl = ret;

    // Show a friendly message if a social login attempt failed
    const err = this.route.snapshot.queryParamMap.get('error');
    if (err) {
      const msgs: Record<string, string> = {
        google_not_configured:   'Google login is not set up yet.',
        facebook_not_configured: 'Facebook login is not set up yet.',
        google_failed:           'Google sign-in failed. Please try again.',
        facebook_failed:         'Facebook sign-in failed. Please try again.',
      };
      this.error = msgs[err] || 'Social login failed.';
    }
  }

  // ── Submit ────────────────────────────────────────────────────────────────
  onSubmit(): void {
    this.error = '';
    this.fieldErrors = {};

    // Client-side required-field checks
    if (!this.email)    { this.fieldErrors['email']    = 'Email is required';    return; }
    if (!this.password) { this.fieldErrors['password'] = 'Password is required'; return; }

    this.loading = true;
    this.auth.login(this.email, this.password).subscribe({
      next: () => {
        this.loading = false;
        // Role-based redirect (rider → rider dashboard, admin → admin panel)
        const role = String(this.auth.currentUser?.role || '');
        if (this.returnUrl && this.returnUrl !== '/dashboard') {
          this.router.navigateByUrl(this.returnUrl);
        } else if (role === 'rider') {
          this.router.navigate(['/rider']);
        } else if (role === 'admin' || role === 'super_admin' || role === 'manager') {
          this.router.navigate(['/admin']);
        } else {
          this.router.navigate(['/dashboard']);
        }
      },
      error: (err: any) => {
        this.loading = false;
        const b = err.error || {};
        // Special case: email not verified yet
        if (b.code === 'EMAIL_NOT_VERIFIED') {
          this.error = b.message || 'Please verify your email first.';
          this.unverifiedEmail = b.email || this.email;
        } else {
          this.error = b.message || 'Login failed. Please try again.';
        }
      },
    });
  }

  // ── Social login ──────────────────────────────────────────────────────────
  loginWithGoogle():   void { window.location.href = this.auth.googleLoginUrl(); }
  loginWithFacebook(): void { window.location.href = this.auth.facebookLoginUrl(); }
}
