import { Component, OnDestroy, ElementRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../../services/auth.service';

type Step = 'role' | 'details' | 'password' | 'otp' | 'done';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnDestroy {
  step: Step = 'role';
  role: 'renter' | 'owner' | 'rider' = 'renter';
  vehicleType = 'bike';

  name = ''; email = ''; phone = ''; password = ''; confirmPass = ''; cnicNumber = '';
  showPass = false; showConfirm = false;
  loading = false; error = '';
  fieldErrors: Record<string, string> = {};

  // OTP
  otpDigits = ['', '', '', '', '', ''];
  otpLoading = false;
  otpError = '';
  otpSuccess = '';
  resendCooldown = 0;
  resendAttempts = 0;
  private resendTimer: any;

  // Email validation
  emailTouched = false;
  emailValid = false;
  emailChecking = false;

  // Cloudflare Turnstile
  turnstileToken = '';
  turnstileError = '';
  turnstileWidgetId: any = null;
  turnstileLoaded = false;
  readonly TURNSTILE_SITE_KEY = '0x4AAAAAADRGoMTytXmXVSW-';

  // CNIC camera scan
  scanning = false;
  cameraStream: MediaStream | null = null;
  scanError = '';
  // CNIC front/back capture + OCR
  scanSide: 'front' | 'back' = 'front';
  cnicFrontImage: string | null = null;
  cnicBackImage: string | null = null;
  ocrLoading = false;
  ocrName: string | null = null;
  cnicConsent = false;
  @ViewChild('videoEl') videoEl!: ElementRef<HTMLVideoElement>;
  @ViewChild('canvasEl') canvasEl!: ElementRef<HTMLCanvasElement>;

  // Voice
  voiceActive = false;
  voiceSupported = 'speechSynthesis' in window;

  private voiceMap: Record<string, string> = {
    page:        'Create your RentAnything account. First, choose your account type.',
    role_renter: 'Renter account selected. You can browse and rent items from owners.',
    role_owner:  'Owner account selected. You can list items and earn money.',
    role_rider:  'Rider account selected. You can deliver items and earn money.',
    name:        'Full Name field. Enter your complete name.',
    email:       'Email Address field. Enter a valid email like ali at gmail dot com.',
    phone:       'Phone Number field. Enter your Pakistani mobile number starting with zero three.',
    cnicNumber:  'CNIC Number field. Enter your national identity card number.',
    password:    'Password field. Enter a strong password with at least 6 characters.',
    confirmPass: 'Confirm Password field. Re-enter the same password.',
    otp:         'Verification code sent to your email. Enter the 6-digit code.',
  };

  constructor(private auth: AuthService, private router: Router) {}

  ngOnDestroy() {
    this.stopCamera();
    this.stopVoice();
    clearInterval(this.resendTimer);
  }

  // ── Role ──────────────────────────────────────────────
  selectRole(r: 'renter' | 'owner' | 'rider') {
    this.role = r;
    if (this.voiceActive) this.speak(this.voiceMap[`role_${r}`]);
    setTimeout(() => {
      this.step = 'details';
      setTimeout(() => this.initTurnstile(), 400);
    }, 300);
  }

  initTurnstile() {
    const w = (window as any);
    const isLocalhost = ['localhost','127.0.0.1'].includes(window.location.hostname);
    if (isLocalhost || !w.turnstile) {
      this.turnstileLoaded = false;
      this.turnstileToken = 'localhost-bypass';
      return;
    }
    this.turnstileLoaded = true;
    const el = document.getElementById('turnstile-widget');
    if (!el) return;
    if (this.turnstileWidgetId !== null) {
      try { w.turnstile.remove(this.turnstileWidgetId); } catch {}
    }
    this.turnstileToken = '';
    this.turnstileError = '';
    this.turnstileWidgetId = w.turnstile.render('#turnstile-widget', {
      sitekey: this.TURNSTILE_SITE_KEY, theme: 'dark', appearance: 'always',
      'refresh-expired': 'auto',
      callback: (token: string) => { this.turnstileToken = token; this.turnstileError = ''; },
      'expired-callback': () => { this.turnstileToken = ''; this.turnstileError = 'Verification expired.'; },
      'error-callback':   () => { this.turnstileToken = ''; this.turnstileError = 'Verification failed.'; },
    });
  }

  // ── Email validation ───────────────────────────────────
  validateEmail(v: string): boolean {
    return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v);
  }

  onEmailBlur() {
    this.emailTouched = true;
    this.emailValid = this.validateEmail(this.email);
    if (!this.email) { delete this.fieldErrors['email']; return; }
    if (!this.emailValid) { this.fieldErrors['email'] = 'Enter a valid email (e.g. ali@gmail.com)'; return; }
    this.emailChecking = true;
    this.auth.checkEmailExists(this.email.toLowerCase()).subscribe({
      next: (res: any) => {
        this.emailChecking = false;
        if (res?.exists) { this.fieldErrors['email'] = 'Email already registered. Please login.'; this.emailValid = false; }
        else delete this.fieldErrors['email'];
      },
      error: () => { this.emailChecking = false; delete this.fieldErrors['email']; }
    });
  }

  onEmailInput() {
    if (this.emailTouched) {
      this.emailValid = this.validateEmail(this.email);
      if (this.email && !this.emailValid) this.fieldErrors['email'] = 'Enter a valid email (e.g. ali@gmail.com)';
      else delete this.fieldErrors['email'];
    }
  }

  // ── CNIC format ────────────────────────────────────────
  formatCNIC(event: Event) {
    const input = event.target as HTMLInputElement;
    let val = input.value.replace(/[^0-9]/g, '');
    if (val.length > 13) val = val.slice(0, 13);
    if (val.length > 12) val = val.slice(0,5)+'-'+val.slice(5,12)+'-'+val.slice(12);
    else if (val.length > 5) val = val.slice(0,5)+'-'+val.slice(5);
    this.cnicNumber = val; input.value = val;
    if (val.length === 15) this.validateCNICField();
    else delete this.fieldErrors['cnicNumber'];
  }

  validateCNICField(): boolean {
    if (!/^[0-9]{5}-[0-9]{7}-[0-9]$/.test(this.cnicNumber)) {
      this.fieldErrors['cnicNumber'] = 'Invalid CNIC format (e.g. 42101-1234567-1)'; return false;
    }
    const c = this.cnicNumber.replace(/-/g,'');
    if (![1,2,3,4,5,6].includes(parseInt(c[0]))) { this.fieldErrors['cnicNumber'] = 'Invalid province code (1-6)'; return false; }
    if (![1,2].includes(parseInt(c[12])))         { this.fieldErrors['cnicNumber'] = 'Last digit must be 1 (Male) or 2 (Female)'; return false; }
    if (/^(.)\1+$/.test(c))                        { this.fieldErrors['cnicNumber'] = 'Invalid CNIC — all digits cannot be same'; return false; }
    delete this.fieldErrors['cnicNumber'];
    return true;
  }

  // ── CNIC Camera ────────────────────────────────────────
  async startCNICScan(side: 'front' | 'back' = 'front') {
    this.scanSide = side;
    this.scanError = ''; this.scanning = true;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode:'environment' } });
      this.cameraStream = stream;
      setTimeout(() => {
        if (this.videoEl?.nativeElement) { this.videoEl.nativeElement.srcObject = stream; this.videoEl.nativeElement.play(); }
      }, 100);
    } catch { this.scanning = false; this.scanError = 'Camera access denied. Enter CNIC manually.'; }
  }

  captureFrame() {
    if (!this.videoEl?.nativeElement || !this.canvasEl?.nativeElement) return;
    const video = this.videoEl.nativeElement; const canvas = this.canvasEl.nativeElement;
    canvas.width = video.videoWidth; canvas.height = video.videoHeight;
    canvas.getContext('2d')?.drawImage(video, 0, 0);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
    this.stopCamera();

    if (this.scanSide === 'front') {
      this.cnicFrontImage = dataUrl;
      this.runCNICOcr(dataUrl);   // read number/name from front
    } else {
      this.cnicBackImage = dataUrl;
      this.scanError = 'Back side captured.';
    }
  }

  /** Send the front image to Gemini OCR and auto-fill the CNIC number/name. */
  private runCNICOcr(dataUrl: string) {
    this.ocrLoading = true;
    this.scanError = 'Reading CNIC…';
    const fd = new FormData();
    fd.append('imageBase64', dataUrl);
    fd.append('mime', 'image/jpeg');
    this.auth.scanCNIC(fd).subscribe({
      next: (res: any) => {
        this.ocrLoading = false;
        if (res?.readable && res?.data?.cnicNumber) {
          this.cnicNumber = res.data.cnicNumber;
          this.ocrName = res.data.name || null;
          this.scanError = 'CNIC read successfully — please verify the number below.';
        } else {
          this.scanError = res?.message || 'Could not read CNIC. Retake the front photo or enter manually.';
        }
      },
      error: () => {
        this.ocrLoading = false;
        this.scanError = 'CNIC scan failed. Please enter the number manually.';
      },
    });
  }

  stopCamera() {
    if (this.cameraStream) { this.cameraStream.getTracks().forEach(t => t.stop()); this.cameraStream = null; }
    this.scanning = false;
  }

  // ── Steps ──────────────────────────────────────────────
  nextToPassword() {
    this.fieldErrors = {};
    if (!this.name.trim() || this.name.trim().length < 2) { this.fieldErrors['name'] = 'Name must be at least 2 characters'; return; }
    if (!this.email || !this.validateEmail(this.email))   { this.fieldErrors['email'] = 'Enter a valid email (e.g. ali@gmail.com)'; return; }
    if (this.fieldErrors['email']) return;
    if (document.getElementById('turnstile-widget')?.children.length && !this.turnstileToken) { this.turnstileError = 'Please complete human verification.'; return; }
    if (this.phone && !/^03[0-9]{9}$/.test(this.phone)) { this.fieldErrors['phone'] = 'Enter valid Pakistani number (e.g. 03001234567)'; return; }
    if (this.role === 'rider') {
      if (!this.phone)       { this.fieldErrors['phone']       = 'Phone is required for riders'; return; }
      if (!this.vehicleType) { this.fieldErrors['vehicleType'] = 'Choose a vehicle'; return; }
      if (!this.cnicNumber)  { this.fieldErrors['cnicNumber']  = 'CNIC is required for riders'; return; }
      if (!this.cnicConsent) { this.fieldErrors['cnicConsent']  = 'Please agree to CNIC verification'; return; }
    }
    if (this.role === 'owner') {
      if (!this.phone)       { this.fieldErrors['phone']      = 'Phone is required for owners'; return; }
      if (!this.cnicNumber)  { this.fieldErrors['cnicNumber'] = 'CNIC is required for owners'; return; }
      if (!this.validateCNICField()) return;
    }
    this.step = 'password';
  }

  submit() {
    this.fieldErrors = {};
    const minPass = (this.role === 'owner' || this.role === 'rider') ? 8 : 6;
    if (!this.password || this.password.length < minPass) { this.fieldErrors['password'] = `Password must be at least ${minPass} characters`; return; }
    if (this.password !== this.confirmPass) { this.fieldErrors['confirmPass'] = 'Passwords do not match'; return; }

    this.loading = true; this.error = '';
    const call$ = this.role === 'owner'
      ? this.auth.registerOwner({ name:this.name.trim(), email:this.email.toLowerCase(), phone:this.phone, cnicNumber:this.cnicNumber, password:this.password, confirmPassword:this.confirmPass, turnstileToken:this.turnstileToken })
      : this.role === 'rider'
      ? this.auth.registerRider({ name:this.name.trim(), email:this.email.toLowerCase(), phone:this.phone, cnicNumber:this.cnicNumber, vehicleType:this.vehicleType, password:this.password, confirmPassword:this.confirmPass, turnstileToken:this.turnstileToken, cnicConsent:this.cnicConsent, cnicImageFront:this.cnicFrontImage, cnicImageBack:this.cnicBackImage })
      : this.auth.registerRenter({ name:this.name.trim(), email:this.email.toLowerCase(), password:this.password, confirmPassword:this.confirmPass, turnstileToken:this.turnstileToken, ...(this.phone ? {phone:this.phone} : {}) });

    call$.subscribe({
      next: (res: any) => {
        this.loading = false;
        if (res?.success === false) { this.error = res.message || 'Registration failed.'; return; }
        // Registration done — go to OTP step
        this.step = 'otp';
        this.startResendCooldown(60);
        if (this.voiceActive) this.speak(this.voiceMap['otp']);
      },
      error: (err: any) => this.handleError(err)
    });
  }

  // ── OTP ────────────────────────────────────────────────
  get otpValue(): string { return this.otpDigits.join(''); }

  /** Single-input OTP: keep digits only, max 6, sync into otpDigits. */
  otpSingle = '';
  onOtpSingleInput(e: Event) {
    const raw = (e.target as HTMLInputElement).value.replace(/\D/g, '').slice(0, 6);
    this.otpSingle = raw;
    this.otpDigits = [0,1,2,3,4,5].map(i => raw[i] || '');
    this.otpError = '';
    if (raw.length === 6) setTimeout(() => this.verifyOTP(), 200);
  }

  onOtpInput(i: number, e: Event) {
    const val = (e.target as HTMLInputElement).value.replace(/\D/g, '');
    this.otpDigits[i] = val.slice(-1);
    this.otpError = '';
    if (val && i < 5) {
      const next = document.getElementById(`otp-reg-${i+1}`);
      if (next) (next as HTMLInputElement).focus();
    }
    // Auto-submit when all 6 filled
    if (this.otpValue.length === 6) setTimeout(() => this.verifyOTP(), 200);
  }

  onOtpKeydown(i: number, e: KeyboardEvent) {
    if (e.key === 'Backspace' && !this.otpDigits[i] && i > 0) {
      const prev = document.getElementById(`otp-reg-${i-1}`);
      if (prev) (prev as HTMLInputElement).focus();
    }
  }

  onOtpPaste(e: ClipboardEvent) {
    e.preventDefault();
    const text = e.clipboardData?.getData('text')?.replace(/\D/g, '').slice(0, 6) || '';
    text.split('').forEach((ch, i) => { if (i < 6) this.otpDigits[i] = ch; });
    if (text.length === 6) setTimeout(() => this.verifyOTP(), 200);
  }

  verifyOTP() {
    if (this.otpValue.length !== 6) { this.otpError = 'Please enter all 6 digits.'; return; }
    this.otpLoading = true; this.otpError = '';
    this.auth.verifyRegistrationOTP(this.email.toLowerCase(), this.otpValue).subscribe({
      next: (res: any) => {
        this.otpLoading = false;
        this.otpSuccess = 'Email verified! Redirecting...';
        setTimeout(() => this.step = 'done', 1500);
      },
      error: (err: any) => {
        this.otpLoading = false;
        const b = err.error || {};
        if (b.code === 'OTP_EXPIRED')      { this.otpError = 'Code expired. Please request a new one.'; }
        else if (b.code === 'OTP_INVALID') { this.otpError = `Wrong code. ${b.attemptsLeft || ''} attempts remaining.`; }
        else if (b.code === 'OTP_MAXED')   { this.otpError = 'Too many wrong attempts. Resend a new code.'; this.otpDigits = ['','','','','','']; }
        else                                { this.otpError = b.message || 'Invalid code. Try again.'; }
      }
    });
  }

  resendOTP() {
    if (this.resendCooldown > 0 || this.resendAttempts >= 3) return;
    this.otpLoading = true; this.otpError = ''; this.otpSuccess = '';
    this.auth.resendVerification(this.email.toLowerCase()).subscribe({
      next: () => {
        this.otpLoading = false;
        this.resendAttempts++;
        this.otpDigits = ['','','','','',''];
        this.otpSuccess = 'New code sent! Check your email.';
        this.startResendCooldown(this.resendAttempts >= 2 ? 120 : 60);
        setTimeout(() => this.otpSuccess = '', 4000);
      },
      error: (err: any) => {
        this.otpLoading = false;
        this.otpError = err.error?.message || 'Could not resend. Try again later.';
      }
    });
  }

  startResendCooldown(secs: number) {
    clearInterval(this.resendTimer);
    this.resendCooldown = secs;
    this.resendTimer = setInterval(() => {
      this.resendCooldown--;
      if (this.resendCooldown <= 0) clearInterval(this.resendTimer);
    }, 1000);
  }

  // ── Helpers ────────────────────────────────────────────
  handleError(err: any) {
    this.loading = false;
    if (!err.error || err.status === 0) { this.error = 'Cannot connect to server. Make sure backend is running.'; return; }
    const body = err.error || {};
    const fieldMap: Record<string, string> = {
      confirmPassword:'confirmPass', cnicNumber:'cnicNumber',
      name:'name', email:'email', phone:'phone', password:'password',
    };
    if (body.errors?.length) {
      body.errors.forEach((e: any) => { this.fieldErrors[fieldMap[e.field]||e.field] = e.message; });
      this.error = body.message || 'Please fix the errors above.';
    } else {
      this.error = body.message || 'Registration failed. Please try again.';
    }
    if (this.voiceActive && this.error) this.speak(this.error);
  }

  goBack() {
    if (this.step === 'details')  this.step = 'role';
    if (this.step === 'password') this.step = 'details';
    if (this.step === 'otp')      this.step = 'password';
  }

  loginWithGoogle()   { window.location.href = this.auth.googleLoginUrl(); }
  loginWithFacebook() { window.location.href = this.auth.facebookLoginUrl(); }

  toggleVoice() {
    this.voiceActive = !this.voiceActive;
    if (this.voiceActive) this.speak(this.voiceMap['page']);
    else this.stopVoice();
  }
  speakField(key: string) { if (this.voiceActive) this.speak(this.voiceMap[key] || key); }
  speak(text: string) {
    if (!this.voiceSupported) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = 'en-US'; u.rate = 0.88; u.pitch = 1;
    window.speechSynthesis.speak(u);
  }
  stopVoice() { if (this.voiceSupported) window.speechSynthesis.cancel(); }

  get stepNum(): number { return {role:1,details:2,password:3,otp:4,done:5}[this.step]||1; }
  get totalSteps(): number { return 4; }
  get maskedEmail(): string {
    const [user, domain] = this.email.split('@');
    return user.substring(0,2) + '***@' + domain;
  }
}
